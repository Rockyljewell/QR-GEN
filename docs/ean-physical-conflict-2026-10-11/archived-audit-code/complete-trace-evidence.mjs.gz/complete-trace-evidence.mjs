// Complete supplementary extraction. No decoder execution or original-result changes.
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url)),sha=b=>createHash('sha256').update(b).digest('hex');
const planBytes=readFileSync(join(here,'plan.json')),plan=JSON.parse(planBytes);
const source=readFileSync(plan.inputs.rowTrace.path);if(sha(source)!==plan.inputs.rowTrace.sha256)throw Error('Row trace changed');
const trace=JSON.parse(source),ids=['ean13-2-07-original','ean13-2-07-chrome-full','ean13-1-35-original','ean13-1-35-derived'];
const cases=ids.map(id=>{const entries=trace.cases.filter(c=>c.id===id);if(entries.length!==1)throw Error('Missing/duplicate required trace '+id);return entries[0];});
const complete=cases.map(c=>({id:c.id,width:c.width,height:c.height,engineGroups:c.engine,acceptedGroups:Object.entries(c.groups).map(([label,rows],index)=>({groupIndex:index,axisCounts:Object.fromEntries([...new Set(rows.map(r=>r.axis))].map(a=>[a,rows.filter(r=>r.axis===a).length])),rowCoordinates:rows.map(r=>r.row),thresholds:rows.map(r=>r.threshold),labelAttachedAfterMeasurement:label}))}));
const records=readFileSync(plan.inputs.baselineProfiles.path,'utf8').trim().split(/\r?\n/).map(JSON.parse);
const limits=records.filter(r=>r.arm==='focused-limits-formats-addons'&&r.itemKey.endsWith('/ean13-1-35')&&r.options.formatLabel==='EAN13'&&r.options.eanAddOnSymbol==='Ignore');
if(limits.length!==24)throw Error('Expected original/derived35 × fast/hard × downscale off/on × max1/2/255');
const results=limits.map(r=>({profileId:r.profileId,itemKey:r.itemKey,options:r.options,results:r.baseline.results,error:r.baseline.error}));
const output={scope:'Supplementary complete accepted-row extraction and existing actual-reader max-limit output evidence; no new decoding.',planSha256:sha(planBytes),rowTraceSha256:sha(source),baselineRecordsSha256:plan.inputs.baselineProfiles.sha256,runnerSha256:sha(readFileSync(fileURLToPath(import.meta.url))),correction:'The initial results.json traceSummaries filter used an incorrect Chrome case ID and contains3trace summaries. Its full479geometry and9control-decoding outputs are unaffected. This supplement explicitly requires all4frozen focus trace IDs, including ean13-2-07-chrome-full, and retains original results unchanged.',completeTraceSummaries:complete,existingMaxLimitProfiles:results,informationNotPresent:['Complete attempted-row schedule and rejected rows for actual max1/2 engine calls.','Exact collector group/merge/discard decisions and identities on those calls.','Complete physical-bar support or region mask.','Newly instrumented native/WASM traces; no rebuild was performed.']};
const out=join(here,'complete-trace-and-limit-evidence.json');if(existsSync(out))throw Error('Existing supplement is immutable');writeFileSync(out,JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({out,completeTraces:complete.length,existingActualLimitProfiles:results.length,hardFullResolution:results.filter(r=>r.options.tryHarder&&!r.options.tryDownscale).map(r=>({itemKey:r.itemKey,max:r.options.maxNumberOfSymbols,results:r.results.map(s=>({text:s.text,lineCount:s.lineCount,position:s.position}))}))},null,2));
