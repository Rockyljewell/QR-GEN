// Artifact-only frozen geometry feasibility. No grouping policy or decoder patch.
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url)),planPath=join(here,'plan.json');
const sha=b=>createHash('sha256').update(b).digest('hex');
const planBytes=readFileSync(planPath),plan=JSON.parse(planBytes),planSha=sha(planBytes);
if(planSha!=='d50418f8906c4788fca6c8611916631b60fccdbab57dd5331fe6fb7bb9acdb1f')throw Error('Frozen protocol changed');
for(const [name,input]of Object.entries(plan.inputs)){const b=readFileSync(input.path);if(b.length!==input.bytes||sha(b)!==input.sha256)throw Error('Input changed: '+name);}
if(existsSync(join(here,'results.json'))||existsSync(join(here,'control-rasters.json')))throw Error('Existing evidence cannot be overwritten');
const req=createRequire(resolve(dirname(plan.inputs.sdk.path),'../package.json')),{PNG}=req('pngjs');
const sdk=await import(pathToFileURL(plan.inputs.sdk.path).href);
const A='5901234123457',B='9780306406157',sourcePngs=new Map();
for(const text of [A,B])sourcePngs.set(text,PNG.sync.read(await sdk.generatePNG(text,plan.generator.options)));
const controls=[];mkdirSync(join(here,'controls'),{recursive:true});
function rotate90(p){const q=new PNG({width:p.height,height:p.width});for(let y=0;y<p.height;y++)for(let x=0;x<p.width;x++)p.data.copy(q.data,((x*q.width)+(p.height-1-y))*4,(y*p.width+x)*4,(y*p.width+x)*4+4);return q;}
for(const spec of plan.controls){
 const images=spec.payloads.map(t=>sourcePngs.get(t)),width=images[0].width,height=images[0].height,padding=20;
 let p,placements=[];
 if(spec.kind==='two'){
  const offset=spec.offset==='half-image-width'?Math.floor(width/2):spec.offset;
  const positions=spec.direction==='along-symbol'?[[padding,padding],[padding+width+spec.gap,padding]]:[[padding,padding],[padding+offset,padding+height+spec.gap]];
  const w=Math.max(...positions.map((p,i)=>p[0]+images[i].width))+padding,h=Math.max(...positions.map((p,i)=>p[1]+images[i].height))+padding;
  p=new PNG({width:w,height:h});p.data.fill(255);
  for(let i=0;i<images.length;i++){PNG.bitblt(images[i],p,0,0,images[i].width,images[i].height,...positions[i]);placements.push({sourceIndex:i,x:positions[i][0],y:positions[i][1],width:images[i].width,height:images[i].height});}
 }else{
  p=new PNG({width:width+padding*2,height:height+padding*2});p.data.fill(255);PNG.bitblt(images[0],p,0,0,width,height,padding,padding);
  const top=padding+Math.floor((height-spec.band)/2);
  for(let y=top;y<top+spec.band;y++)p.data.fill(255,(y*p.width+padding)*4,(y*p.width+padding+width)*4);
  placements=[{sourceIndex:0,x:padding,y:padding,width,height,whiteBand:{top,height:spec.band}}];
 }
 if(spec.rotate===90)p=rotate90(p);
 const bytes=PNG.sync.write(p),path=join(here,'controls',spec.id+'.png');writeFileSync(path,bytes);
 controls.push({id:spec.id,spec,path,width:p.width,height:p.height,pngSha256:sha(bytes),rgbaSha256:sha(p.data),placementsBeforeRotation:placements,pixels:p.data});
}
const controlManifest={frozenAt:new Date().toISOString(),planSha256:planSha,generatorSha256:plan.inputs.sdk.sha256,controls:controls.map(({pixels,...r})=>r)};
const controlManifestBytes=Buffer.from(JSON.stringify(controlManifest,null,2)+'\n');writeFileSync(join(here,'control-rasters.json'),controlManifestBytes);
// Geometry receives only four returned points. No payload, truth, support or validity is used.
function geometry(position){
 const pts=['topLeft','topRight','bottomRight','bottomLeft'].map(k=>position[k]);
 if(pts.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)))throw Error('Nonfinite position');
 const dx=(pts[1].x+pts[2].x-pts[0].x-pts[3].x)/2,dy=(pts[1].y+pts[2].y-pts[0].y-pts[3].y)/2;
 const axis=Math.abs(dx)>=Math.abs(dy)?'x':'y',perp=axis==='x'?'y':'x';
 const values=pts.map(p=>p[axis]),perps=pts.map(p=>p[perp]);
 return {axis,dx,dy,angleDegrees:Math.atan2(dy,dx)*180/Math.PI,span:[Math.min(...values),Math.max(...values)],supportEnvelope:[Math.min(...perps),Math.max(...perps)],aabb:{x:[Math.min(...pts.map(p=>p.x)),Math.max(...pts.map(p=>p.x))],y:[Math.min(...pts.map(p=>p.y)),Math.max(...pts.map(p=>p.y))]},position};
}
function pairs(positions){
 const gs=positions.map(geometry),ps=[];
 for(let a=0;a<gs.length;a++)for(let b=a+1;b<gs.length;b++){
  const x=gs[a],y=gs[b],sameAxis=x.axis===y.axis,overlap=sameAxis?Math.max(0,Math.min(x.span[1],y.span[1])-Math.max(x.span[0],y.span[0])):null;
  const union=sameAxis?Math.max(x.span[1],y.span[1])-Math.min(x.span[0],y.span[0]):null;
  const gap=sameAxis?Math.max(0,Math.max(x.supportEnvelope[0],y.supportEnvelope[0])-Math.min(x.supportEnvelope[1],y.supportEnvelope[1])):null;
  const areaIntersect=['x','y'].every(k=>Math.min(x.aabb[k][1],y.aabb[k][1])-Math.max(x.aabb[k][0],y.aabb[k][0])>0);
  ps.push({a,b,sameDominantAxis:sameAxis,exactParallel:x.dx*y.dy-x.dy*y.dx===0,spanOverlap:overlap,spanIntersectionOverUnion:sameAxis&&union>0?overlap/union:null,perpendicularEnvelopeGap:gap,gapOverShorterSymbolSpan:sameAxis?gap/Math.min(x.span[1]-x.span[0],y.span[1]-y.span[0]):null,positiveAabbIntersection:areaIntersect,projectionOnlyRelated:sameAxis&&overlap>0});
 }
 const components=[],seen=new Set();for(let i=0;i<gs.length;i++){if(seen.has(i))continue;const pending=[i],component=[];seen.add(i);while(pending.length){const a=pending.pop();component.push(a);for(const p of ps)if(p.projectionOnlyRelated&&(p.a===a||p.b===a)){const b=p.a===a?p.b:p.a;if(!seen.has(b)){seen.add(b);pending.push(b);}}}components.push(component.sort((a,b)=>a-b));}
 return {envelopes:gs,pairs:ps,projectionComponents:components};
}
const recorded=readFileSync(plan.inputs.baselineProfiles.path,'utf8').trim().split(/\r?\n/).map(JSON.parse),frozen=JSON.parse(readFileSync(plan.inputs.frozenPlan.path));
const items=new Map(frozen.items.map(i=>[i.group+'/'+i.id,i]));
const selected=recorded.filter(r=>r.arm==='full-frozen-corpus'&&r.options.tryHarder===true&&r.options.tryDownscale===false);
if(selected.length!==479)throw Error('Frozen scope is not 479 rasters');
const expected=plan.controlReader.options;
for(const r of selected)for(const k of Object.keys(expected))if(JSON.stringify(r.options[k])!==JSON.stringify(expected[k]))throw Error('Unexpected frozen option: '+k+' on '+r.itemKey);
const frozenGeometry=selected.map(r=>({profileId:r.profileId,itemKey:r.itemKey,resultCount:r.baseline.results.length,...pairs(r.baseline.results.map(r=>r.position)),annotationsAfterGeometry:r.baseline.results.map(r=>({text:r.text,format:r.format,bytesHex:r.bytesHex,lineCount:r.lineCount}))}));
const focusNames=['original-RGBA-white-sRGB/ean13-1-35','derived-limited-Y-expanded-RGB/ean13-1-35','original-RGBA-white-sRGB/ean13-2-07','actual-Chrome-supplement/actual-Chrome-ean13-2-07-full'];
const focus=frozenGeometry.filter(r=>focusNames.includes(r.itemKey));if(focus.length!==4)throw Error('Missing focus geometry');
const readerPath=req.resolve('zxing-wasm/reader'),readerES=resolve(dirname(readerPath),'../../es/reader/index.js');
const reader=await import(pathToFileURL(readerES).href+'?physical-conflict-frozen-study');
if(reader.ZXING_WASM_VERSION!=='3.1.5'||reader.ZXING_CPP_COMMIT!=='2ecec3f5be0ee803f6e14a5a2c7028c0cfe525b4')throw Error('Unexpected release engine');
const wasm=readFileSync(plan.inputs.releasedWasm.path);if(sha(wasm)!=='aecc1876de036c62c8419f67a5e1a16b1698a325bcd190aa84810d516e263931')throw Error('Wrong release WASM');
await reader.prepareZXingModule({overrides:{wasmBinary:wasm.buffer.slice(wasm.byteOffset,wasm.byteOffset+wasm.byteLength)},fireImmediately:true});
function plain(value){if(ArrayBuffer.isView(value))return{typedArray:value.constructor.name,bytesHex:Buffer.from(value.buffer,value.byteOffset,value.byteLength).toString('hex')};if(Array.isArray(value))return value.map(plain);if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,plain(v)]));return value;}
const controlResults=[];
for(const control of controls){
 const start=performance.now(),results=await reader.readBarcodes({width:control.width,height:control.height,data:control.pixels},expected);
 const g=pairs(results.map(r=>r.position));
 const texts=results.map(r=>r.text);controlResults.push({id:control.id,pngSha256:control.pngSha256,rgbaSha256:control.rgbaSha256,resultCount:results.length,...g,annotationsAfterGeometry:results.map(r=>({text:r.text,format:r.format,lineCount:r.lineCount})),allReturnedFields:results.map(plain),expectedAfterGeometry:{physicalSymbols:control.spec.kind==='two'?2:1,payloads:control.spec.payloads,expectedPayloadPresent:control.spec.payloads.map(t=>texts.includes(t)),countAgreement:results.length===(control.spec.kind==='two'?2:1)},elapsedMs:performance.now()-start});
}
const trace=JSON.parse(readFileSync(plan.inputs.rowTrace.path));
const traceCases=trace.cases.filter(c=>['ean13-1-35-original','ean13-1-35-derived','ean13-2-07-original','ean13-2-07-actual-Chrome-full'].includes(c.id));
// Keep all group entries and counts: repeated payloads are never deduplicated as geometry.
const traceSummaries=traceCases.map(c=>({id:c.id,width:c.width,height:c.height,engineGroups:c.engine,acceptedGroups:Object.entries(c.groups).map(([label,rows],index)=>({groupIndex:index,axisCounts:Object.fromEntries([...new Set(rows.map(r=>r.axis))].map(a=>[a,rows.filter(r=>r.axis===a).length])),rowCoordinates:rows.map(r=>r.row),thresholds:rows.map(r=>r.threshold),labelAttachedAfterMeasurement:label}))}));
const related=frozenGeometry.filter(r=>r.pairs.some(p=>p.projectionOnlyRelated));
const falseGroupingControls=controlResults.filter(r=>r.expectedAfterGeometry.physicalSymbols===2&&r.pairs.some(p=>p.projectionOnlyRelated));
const final={schemaVersion:1,recordedAt:new Date().toISOString(),scope:plan.scope,planSha256:planSha,controlManifestSha256:sha(controlManifestBytes),runnerSha256:sha(readFileSync(fileURLToPath(import.meta.url))),reader:{version:reader.ZXING_WASM_VERSION,cppCommit:reader.ZXING_CPP_COMMIT,wasmSha256:sha(wasm),moduleSha256:sha(readFileSync(readerES)),options:expected},frozenProfiles:selected.length,focus,allFrozenGeometry:frozenGeometry,projectionRelatedFrozenCases:related.map(r=>({profileId:r.profileId,itemKey:r.itemKey,resultCount:r.resultCount,pairs:r.pairs.filter(p=>p.projectionOnlyRelated),annotationsAfterGeometry:r.annotationsAfterGeometry})),controlResults,traceSummaries,decision:{projectionOnlyPhysicalIdentityRuleRefuted:falseGroupingControls.length>0,falseGroupingControlIds:falseGroupingControls.map(r=>r.id),safeProductionFilterEstablished:false,reason:'A same-projection relation can flag legitimate separate aligned symbols. Returned support envelopes and sparse accepted-row metadata cannot certify complete physical-symbol identity or distinguish close labels from one distorted/occluded symbol. No threshold/winner was fitted.'},limitations:plan.limitations};
writeFileSync(join(here,'results.json'),JSON.stringify(final,null,2)+'\n');
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const colors=['#e8504e','#1c83c6','#198b58','#b56bca'];
function imageSection(id,png,entry){const p=PNG.sync.read(readFileSync(png));return '<section><h2>'+esc(id)+'</h2><svg viewBox="0 0 '+p.width+' '+p.height+'" role="img"><image width="'+p.width+'" height="'+p.height+'" href="data:image/png;base64,'+readFileSync(png).toString('base64')+'"/>'+entry.envelopes.map((g,i)=>'<polygon points="'+Object.values(g.position).map(p=>p.x+','+p.y).join(' ')+'" fill="none" stroke="'+colors[i%colors.length]+'" stroke-width="3"/><text x="'+g.position.topLeft.x+'" y="'+Math.max(16,g.position.topLeft.y-5)+'" fill="'+colors[i%colors.length]+'" font-size="16">group '+i+'</text>').join('')+'</svg><pre>'+esc(JSON.stringify({groups:entry.annotationsAfterGeometry,pairs:entry.pairs},null,2))+'</pre></section>';}
const focusPaths=new Map([[focusNames[0],plan.inputs.original35.path],[focusNames[1],plan.inputs.derived35.path],[focusNames[2],plan.inputs.original07.path],[focusNames[3],plan.inputs.chrome07.path]]);
const html='<!doctype html><meta charset="utf-8"><title>Physical-symbol conflict feasibility</title><style>body{font:16px system-ui;margin:24px;background:#f4f4f4;color:#222}section{background:white;padding:16px;margin:20px 0;max-width:1100px}svg{width:min(100%,850px);max-height:700px}pre{font:12px monospace;white-space:pre-wrap}h1{font-size:24px}</style><h1>Returned scanline-support envelopes</h1><p>Colors identify result groups only. They do not label truth or confidence. Projection overlap cannot establish one physical barcode. Frozen plan '+planSha+'.</p>'+focus.map(r=>imageSection(r.itemKey,focusPaths.get(r.itemKey),r)).join('')+controlResults.map(r=>imageSection(r.id,controls.find(c=>c.id===r.id).path,r)).join('');
writeFileSync(join(here,'inspection.html'),html);
console.log(JSON.stringify({planSha256:planSha,frozenProfiles:selected.length,focus:focus.map(r=>({itemKey:r.itemKey,groups:r.resultCount,pairs:r.pairs})),projectionRelatedFrozenCases:related.length,controlResults:controlResults.map(r=>({id:r.id,groups:r.resultCount,pairs:r.pairs.filter(p=>p.projectionOnlyRelated),expected:r.expectedAfterGeometry})),decision:final.decision},null,2));
