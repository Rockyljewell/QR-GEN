"""Independent verification of retained public Node matrix; never imports an SDK."""
from pathlib import Path
from collections import Counter
from PIL import Image
import hashlib, json, io

HERE=Path(__file__).resolve().parent
ART=HERE.parent.parent
M=ART/'staged-sdk-node-validation'
S=ART/'staged-sdk-study-v1'
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_bytes())
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False)
failures=[];checks=[]
def check(ok,label,detail=None):
    checks.append({'check':label,'passed':bool(ok),'detail':detail})
    if not ok:failures.append(label)
pb=(M/'frozen-plan.json').read_bytes();p=json.loads(pb);f=load(M/'freeze.json');published=load(M/'matrix-summary.json')
check(sha(pb)==f['planSha256']==published['planSha256']=='1e6042ae022e0e902410aaf8094918cef564c2e01d438a7932598d29fd497a65','Frozen public plan hash')
source_bytes=(ART/'rebuilt-ean/actual-matrix-v1/evaluation-plan.json').read_bytes()
check(sha(source_bytes)==p['sourcePlanSha256']=='03eb911057351f594004eb3450f1a83b60e00360dbadefccda8d709e0403a4ab','Inherited actual reader plan hash')
for name,h in p['runnerSha256'].items():check(sha((M/name).read_bytes())==h,'Frozen pre-execution script '+name)
source=json.loads(source_bytes);selected=[i for i in source['items'] if i.get('core') or i['group']=='generated-72-format-matrix']
check(len(p['items'])==551 and len({i['key'] for i in p['items']})==551,'551 unique retained raster identities')
check(all({k:i[k] for k in original}==original for i,original in zip(p['items'],selected)) and len(p['items'])==len(selected),'All inherited raster metadata and ordering preserved')
for i in p['items']:
    b=Path(i['path']).read_bytes();transport=Path(i['transportPath']).read_bytes()
    check(sha(b)==i['fileSha256'] and sha(transport)==i['transportSha256'],'Frozen source and PNG transport hash '+i['key'])
    with Image.open(io.BytesIO(transport)) as image:
        rgba=image.convert('RGBA'); size=rgba.size; pixels=rgba.tobytes()
    check(size==(i['width'],i['height']) and sha(pixels)==i['rgbaSha256'],'Independent Pillow PNG-to-RGBA transport verification '+i['key'])
check(sum(i['reusedSourceBytes'] for i in p['items'])==502 and sum(not i['reusedSourceBytes'] for i in p['items'])==49,'502 reused and 49 lossless transport PNGs')

profiles=[]
def add(item,arm,formats,hard,limit):
    family=item['matrix']['symbology'] if item.get('matrix') else 'ean13';truth=item['truth'];label='+'.join(formats)
    if not item.get('matrix') and formats==['upca']:
        if isinstance(truth,str) and len(truth)==13 and truth[0]=='0' and truth.isdecimal():family='upca';truth=truth[1:]
        else:truth=None
    elif not item.get('matrix') and len(formats)>1 and isinstance(truth,str) and len(truth)==13 and truth[0]=='0' and truth.isdecimal():family='upca';truth=truth[1:]
    profiles.append({'id':str(len(profiles)),'itemKey':item['key'],'arm':arm,'scope':label,'options':{'symbologies':formats,'tryHarder':hard,'tryInvert':True,'maxResults':limit},'target':None if truth is None else {'data':truth,'symbology':family},'noCode':item['truth'] is None and (item['group']=='generated-no-code' or item['group'].startswith('real-negative-'))})
for i in p['items']:
    if i.get('core'):
        for h in [False,True]:add(i,'frozen-core',['ean13'],h,255)
for i in p['items']:
    if i.get('matrix'):
        for h in [False,True]:add(i,'generated-72-matrix',[i['matrix']['symbology']],h,255)
focus=[i for i in p['items'] if i.get('photo') and (i['id'] in ['ean13-2-07','ean13-1-35'] or i['group']=='actual-Chrome-supplement')]
for i in focus:
    for h in [False,True]:
        for formats in [['ean13'],['upca'],['ean13','upca','ean8','upce','qr','code128']]:
            for limit in [1,2]:add(i,'focused-public-scopes-limits',formats,h,limit)
check(len(profiles)==1162 and profiles==p['profiles'],'Exact independently reconstructed public option and oracle profiles')

reader={'baseline':'aecc1876de036c62c8419f67a5e1a16b1698a325bcd190aa84810d516e263931','candidate':'f9d636340ef9b9b3e433e9c81a1cff228c80c4d9f45b748b6fe116308821ddc6'}
records={};summaries={}
for label in ['baseline','candidate']:
    for fmt in ['esm','cjs']:
        key=label+'-'+fmt;d=M/key;rb=(d/'results.jsonl').read_bytes();rows=[json.loads(x) for x in rb.splitlines()];s=load(d/'summary.json');records[key]=rows;summaries[key]=s
        check(len(rows)==1162 and [r['profileId'] for r in rows]==[x['id'] for x in profiles],'Complete ordered 1162-profile coverage '+key)
        check(sha(rb)==s['resultsSha256'] and s['planSha256']==sha(pb) and s['runnerSha256']==p['runnerSha256']['run-consumer.mjs'],'Result, runner and plan fingerprints '+key)
        entry=S/'consumers'/label/'package/dist'/('node.js' if fmt=='esm' else 'node.cjs')
        check(sha(entry.read_bytes())==s['entrySha256'],'Packed public entry fingerprint '+key)
        check(s['status']=='passed' and s['successful']==1162 and s['errors']==[] and s['mutations']==0 and s['validationFailures']==0 and s['provenanceErrors']==[] and s['networkAttempts']==[],'Retained execution completed with no reported engine/validation/provenance failures '+key)
        check({x['sha256'] for x in s['compiledWasm']}=={reader[label]},'Only expected scanner WASM observed '+key)
        for row,profile in zip(rows,profiles):
            check(all(row[k]==profile[k] for k in ['itemKey','arm','scope','options']) and row['status']=='fulfilled' and row['inputBackingMutation'] is False and row['validationErrors']==[],'Profile identity and returned status '+key+'/'+profile['id'])

vkey=lambda b:canon([b['data'],b['symbology'],b['rawBytes']])
target=lambda b,t:t is not None and b['data']==t['data'] and b['symbology']==t['symbology']
losses=[];full_losses=[];new_values=[];changes=[];no_code=[];matrix_misses=[];residual07=[];false35=[];parity=[]
items={i['key']:i for i in p['items']}
for idx,profile in enumerate(profiles):
    for label in ['baseline','candidate']:
        a=records[label+'-esm'][idx];z=records[label+'-cjs'][idx]
        if a['status']!=z['status'] or a.get('output')!=z.get('output') or a.get('error')!=z.get('error'):parity.append((label,profile['id']))
    b=records['baseline-esm'][idx]['output'];c=records['candidate-esm'][idx]['output']
    bt=[x for x in b if target(x,profile['target'])];ct=[x for x in c if target(x,profile['target'])]
    if Counter(map(vkey,bt))-Counter(map(vkey,ct)):losses.append(profile['id'])
    if Counter(map(canon,bt))-Counter(map(canon,ct)):full_losses.append(profile['id'])
    if Counter(map(vkey,c))-Counter(map(vkey,b)):new_values.append(profile['id'])
    if b!=c:changes.append({'profile':profile,'baseline':b,'candidate':c})
    if profile['noCode'] and (b or c):no_code.append(profile['id'])
    if profile['arm']=='generated-72-matrix' and (not bt or not ct):matrix_misses.append(profile['id'])
    item=items[profile['itemKey']]
    if item['id']=='ean13-2-07' or item['group']=='actual-Chrome-supplement':
        if any(x['data'] in ['0798884816632','798884816632'] for x in c):residual07.append(profile)
    if item['id']=='ean13-1-35' and any(x['data']=='7034759003930' for x in c):false35.append(profile)
check(not parity and not losses and not full_losses and not new_values and not no_code and not matrix_misses,'Independent matrix semantic gates',{'parity':parity,'targetValueLosses':losses,'targetFullRecordLosses':full_losses,'newValues':new_values,'noCodeOutputs':no_code,'generatedMatrixMisses':matrix_misses})
check(len(changes)==10 and all(x['candidate']==[] and len(x['baseline'])==1 and (x['baseline'][0]['data'],x['baseline'][0]['symbology']) in [('0798884816632','ean13'),('798884816632','upca')] for x in changes),'All ten changed profiles remove known wrong07 payload or its public UPC-A alias without new outputs')
check(len(residual07)==4 and all(x['scope']=='upca' and x['arm']=='focused-public-scopes-limits' for x in residual07),'Four residual07 profiles are explicit UPC-A-only focused cases')
check(len(false35)==6,'Six residual wrong35 public profiles')
result={'scope':'Independent read-only retained-public-SDK-matrix and PNG transport review. No SDK import/decode or writes to source evidence.','pillowVersion':__import__('PIL').__version__,'planSha256':sha(pb),'checks':len(checks),'failures':failures,'counts':{'rasters':551,'sourcePngReused':502,'losslessTransports':49,'profilesPerRun':1162,'runs':4,'retainedSdkCalls':4648,'noCodeProfilesPerRun':sum(x['noCode'] for x in profiles),'matrixProfilesPerRun':sum(x['arm']=='generated-72-matrix' for x in profiles),'changedProfilesPerFormat':len(changes),'targetValueLosses':len(losses),'targetFullRecordLosses':len(full_losses),'newValueProfiles':len(new_values),'noCodeOutputProfiles':len(no_code),'generatedMatrixMisses':len(matrix_misses),'esmCjsDifferences':len(parity),'residual07':len(residual07),'residual35':len(false35)},'changes':changes,'residual07':residual07,'residual35':false35,'checkRecords':checks,'limitations':['Repeated profiles/formats are not independent photographs.','Transport verification independently decodes PNG pixels with Pillow; it does not re-execute the SDK image loader.','Runner serializes enumerable string-key own public properties excluding timestamp; current converter returns plain enumerable fields and symbol keys are rejected.','Matrix limits/families/public defaults differ from prior raw reader studies, so residual profile counts cannot be added or directly equated.','No official default CDN, arbitrary caller binary, migration, held-out accuracy, phone or Scandit parity validation.']}
(HERE/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'failures':failures,'counts':result['counts']}))
if failures:raise SystemExit(1)
